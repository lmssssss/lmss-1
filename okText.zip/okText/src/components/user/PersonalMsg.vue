<template>
  <div class="col-md-offset-3">
    <form class="form-horizontal">
      <div class="form-group">
        <b class="col-sm-2 text-right">用户名</b>
        <div class="col-sm-10">
          <b>{{user_Name}}</b>
        </div>
      </div>

      <div class="form-group">
        <b class="col-sm-2 text-right">注册时间</b>
        <div class="col-sm-2">
          <b>{{user_RedistrationTime}}</b>
        </div>
      </div>

      <div class="form-group" id="aa">
        <label for="inputEmail3" class="col-sm-2 control-label">Email</label>
        <div class="col-sm-4">
          <input
            type="email"
            class="form-control"
            id="inputEmail3"
            v-model="user_Email"
            :placeholder="user_Email"
          >
        </div>
      </div>

      <div class="form-group">
        <label for="inputPassword3" class="col-sm-2 control-label">个人简介</label>
        <div class="col-sm-4">
          <textarea
            class="form-control"
            rows="5"
            cols="20"
            style="resize:none"
            id="inputPassword3"
            :placeholder="user_BriefIntroduction"
            v-model="user_BriefIntroduction">
                   {{user_BriefIntroduction}}
          </textarea>
        </div>
      </div>

      <div class="form-group">
        <div class="col-sm-offset-2 col-sm-5">
          <button type="button" class="btn btn-default" @click="upMsg" id="submit">保存修改</button>
        </div>
      </div>
    </form>
  </div>
</template>
<script>
export default {
    name:'PersonalMsg',
    data(){
        return {
            user_Name: 'saf',
            user_Email: 'Email',
            user_RedistrationTime: '',
            user_BriefIntroduction:'请输入你的个人介绍'
    }
}
}
</script>

