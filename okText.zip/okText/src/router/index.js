import Vue from 'vue'
import Router from 'vue-router'
import test1 from '@/components/test1'

import index from '@/components/index'
import login from '@/components/login'
import user from '@/components/user'
import manage from '@/components/manage'
Vue.use(Router)

export default new Router({
  mode: 'history',
  routes: [
    {
      path: '/test1/:id',
      name: 'test1',
      component: test1
    },{
      path: '/',
      name: 'index',
      component: index
    },{
      path: '/user',
      name: 'user',
      component: user
    },{
      path: '/manage',
      name: 'manage',
      component: manage
    },{
      path: '/login',
      name: 'login',
      component: login
    }
  ]
})
