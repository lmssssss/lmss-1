<template>
  <div id="app">
    <!-- <router-link :to="{name:'test1',params:{id:info.id}}" tag="li"> -->
    <!-- <router-link :to="{name:'test1',params:{id:'10'}}" tag='li'>前往路由1</router-link> -->
    <router-view/>
  </div>
</template>

<script>
export default {
  name: 'App'
}
</script>

<style>
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
